/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bsp_W25Q128.h"
#include "Key.h"
#include "delay.h"
#include "Oled.h"
#include "Stepper.h"
#include "Tmc2209.h"
#include "Uart_maixcam.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define K_Mm_To_Step 10 //比如400个脉冲走5mm，说明1mm为八十个脉冲，以mm为单位的话k=80
#define K_Vision_To_Mm 0.463 
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
Stepper_t y_motor;
Stepper_t x_motor;
float y_speed = 0;
float x_speed = 0;
volatile int count_i =0 ;
uint8_t DIR_x = 1;
uint8_t DIR_y = 1;
int tx = 0;//
int ty = 0;//
int bx = 0;//
int by = 0;//
int txmm = 0;//元件到原点的坐标
int tymm = 0;//元件到原点的坐标
int bxmm = 0;//板子到原点的坐标
int bymm = 0;//板子到原点的坐标
int tbx = 0;//元件到扳子的坐标
int tby = 0;//元件与板子的坐标
int zerox = 22;//原点
int zeroy = 5;//原点
volatile int move = 0;//是否启用坐标接收
int version = 1;//基础题1-3，发挥题1-2，如果等于2则代表进入最后的所有元件

// 两个串口独立接收缓冲区
uint8_t uart5_readBuffer[128];
uint8_t usart2_readBuffer[128];




/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/*
以下是龙门架或者T型滑台的控制代码
void Stepper_move_Forward(float mm)
{
	 // 保护：电机非停止状态时不执行
  if (x_motor.state != STOP) return;
	int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&x_motor,target_steps);
}

void Stepper_move_Back(float mm)
{
	 // 保护：电机非停止状态时不执行
  if (x_motor.state != STOP) return;
	int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&x_motor,-target_steps);
}

void Stepper_move_Left(float mm)
{
	 // 保护：电机非停止状态时不执行
  if (y_motor.state != STOP) return;
	int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&y_motor,target_steps);
}

void Stepper_move_Right(float mm)
{
	 // 保护：电机非停止状态时不执行
   if (y_motor.state != STOP) return;
	int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&y_motor,-target_steps);
}
*/

/*
 x装左边y装右边或者x装下面y装上面
 左右电机逆时针forward 左右电机顺时针back 左逆右顺left 左顺右逆right
 电机线在下，逆时针是脉冲大于零，顺时针是脉冲小于零
*/
void Stepper_move_Right(float mm)//xia
{
 // 保护：电机非停止状态时不执行
 if (y_motor.state != STOP) return;
 int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&x_motor,-target_steps);
	Stepper_Move(&y_motor,target_steps);
}

void Stepper_move_Left(float mm)//shang
{
 // 保护：电机非停止状态时不执行
 if (y_motor.state != STOP) return;
 int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&x_motor,target_steps);
	Stepper_Move(&y_motor,-target_steps);
}

void Stepper_move_Forward(float mm)//zuo
{
// 保护：电机非停止状态时不执行
 if (y_motor.state != STOP) return;
 int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&x_motor,-target_steps);
	Stepper_Move(&y_motor,-target_steps);
}

void Stepper_move_Back(float mm)//you
{
// 保护：电机非停止状态时不执行
 if (y_motor.state != STOP) return;
 int32_t target_steps = mm * K_Mm_To_Step;
	Stepper_Move(&x_motor,target_steps);
	Stepper_Move(&y_motor,target_steps);
}

int get_tx_position()
{
 return Uart_getdata(0,1);
}
int get_ty_position()
{
 return Uart_getdata(0,2);
}
int get_bx_position()
{
 return Uart_getdata(1,1);
}
int get_by_position()
{
 return Uart_getdata(1,2);
}

int vision_to_mm(int x1,int x2)
{
	return ((x1-x2)*K_Vision_To_Mm);
}

//按钮触发外部中断
void HAL_GPIO_EXTI_Callback(uint16_t Pin)
{
	if(Pin == GPIO_PIN_13) //KEY2
	{
		version++;
		if(version > 2)
    version=1;
	}
	if(Pin == GPIO_PIN_9)//KEY5
		move = 1;
}

//电磁铁控制函数
//void Magnet_On(void)
//{HAL_GPIO_WritePin(Magnet_GPIO_Port, Magnet_Pin, GPIO_PIN_SET);}
//void Magnet_Off(void)
//{HAL_GPIO_WritePin(Magnet_GPIO_Port, Magnet_Pin, GPIO_PIN_RESET);}

void sg90(int angle)
{
	int pwm = (250 - 50) * angle / 180 + 50;
	__HAL_TIM_SetCompare(&htim9,TIM_CHANNEL_1,pwm);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_UART5_Init();
  MX_USART3_UART_Init();
  MX_TIM5_Init();
  MX_TIM9_Init();
  MX_UART4_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  DWT_Init();
	
	delay_ms(200);
	OLED_Clear();
	Tmc2209_Init(0);
	Tmc2209_Init(1);
	//HAL_TIM_Base_Start_IT(&htim4);
	
	Uart_en_Init();
	
	Stepper_Init(&y_motor,&htim1,TIM_CHANNEL_1,Y_DIR_GPIO_Port,Y_DIR_Pin,MODE_POSITION);
	Stepper_Init(&x_motor,&htim3,TIM_CHANNEL_1,X_DIR_GPIO_Port,X_DIR_Pin,MODE_POSITION);
	Stepper_Set_Speed_Profile(&x_motor,500000,12000);//二细分速度
	Stepper_Set_Speed_Profile(&y_motor,500000,12000);//二细分速度
	HAL_TIM_Base_Start(&htim9);
	HAL_TIM_PWM_Start(&htim9,TIM_CHANNEL_ALL);
//	HAL_GPIO_WritePin(LED_Green_GPIO_Port,LED_Green_Pin,GPIO_PIN_SET);//初始化完成
	//移动到零点，每次请推回最左上角
	Stepper_move_Back(22);
  HAL_Delay(700);
	Stepper_move_Right(5);
  HAL_Delay(700);
	
  //测试用
	//Stepper_Set_Speed_Profile(&x_motor,1000000000000,4000000);十六细分速度
	//Stepper_Set_Speed_Profile(&x_motor,1000000,50000);八细分速度
	//Stepper_Set_Speed_Profile(&x_motor,100000,50000);四细分速度
//	Stepper_move_Right(80);
//	HAL_Delay(700);
//	Stepper_move_Back(80);
//	Stepper_move_Left(800);
//	HAL_Delay(700);
//	Stepper_move_Forward(800);
//	HAL_Delay(700);   
//	Stepper_Move(&x_motor,-4000);
	//HAL_GPIO_WritePin(LED_Yellow_GPIO_Port,LED_Yellow_Pin,GPIO_PIN_SET);
	//HAL_GPIO_WritePin(LED_Red_GPIO_Port,LED_Red_Pin,GPIO_PIN_SET);
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//		switch(Key_Scan()){
//				case 1:
//				move = 1;
//				break;
//				case 2:
//				version++;
//				if(version > 2)
//        {version=1;}
//				if(version == 2)
//     {
//        Uart_Reset_9Groups_Cnt(); 
//     }
//		 		break;
//				case 3:break;
//				case 4:break;
//				
//				default: break;
//			}
    __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, 150);
    HAL_Delay(1000);

    // 向左转，占空比2.5%，即2000 * 2.5% = 50
    __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, 50);
    HAL_Delay(1000);

    // 向右转，占空比12.5%，即2000 * 12.5% = 250
    __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, 250);
    HAL_Delay(1000);

		//红绿灯同时亮代表发挥题最后一题
		//单独亮黄灯代表正在其他题目
		if (version == 2)
//		HAL_GPIO_WritePin(LED_Red_GPIO_Port,LED_Red_Pin,GPIO_PIN_SET);
//		else
//		HAL_GPIO_WritePin(LED_Red_GPIO_Port,LED_Red_Pin,GPIO_PIN_RESET);
			//move不为一的时候停止接收数据
		if(move == 1 && version == 1 )
		{ 
//			HAL_GPIO_WritePin(LED_Yellow_GPIO_Port,LED_Yellow_Pin,GPIO_PIN_SET);
			//接收四个坐标数据
			tx=get_tx_position();
			HAL_Delay(10);
			ty=get_ty_position();
			HAL_Delay(10);
			bx=get_bx_position();
			HAL_Delay(10);
			by=get_by_position();
			HAL_Delay(10);
			//接下来计算实际距离
			txmm = vision_to_mm(tx,zerox);
			tymm = vision_to_mm(ty,zeroy);
			tbx = vision_to_mm(bx,tx);
			tby = vision_to_mm(by,ty);
			bxmm = vision_to_mm(bx,zerox);
			bymm = vision_to_mm(by,zeroy);
			// 先算原点到元件并且吸附
			Stepper_move_Right(tymm);
			HAL_Delay(1100);
			Stepper_move_Back(txmm);
			HAL_Delay(1100);
			//吸附
			//这里写舵机的函数
			sg90(70);
      HAL_Delay(1000);
//			Magnet_On();
      HAL_Delay(200);
			sg90(30);
      HAL_Delay(1000);
			//然后回去
			Stepper_move_Right(tby);
			HAL_Delay(1100);
			Stepper_move_Back(tbx);
			HAL_Delay(1100);
			
			//放下
			//这里写舵机的函数
			sg90(120);
      HAL_Delay(1000);
//			Magnet_Off();
      HAL_Delay(200);
			sg90(0);
      HAL_Delay(1000);
			
			//回到原点
			Stepper_move_Left(bymm);
			HAL_Delay(1100);
			Stepper_move_Forward((bxmm+10));
			HAL_Delay(1100);
			//回归原状
			move=0;
//			HAL_GPIO_WritePin(LED_Yellow_GPIO_Port,LED_Yellow_Pin,GPIO_PIN_RESET);
		}
		
		 if(move == 1 && version == 2)
    {
        //等待UART5和USART2的9组数据都接收完成
        if(t_9groups_ready ==1 && b_9groups_ready == 1)
        {
//					HAL_GPIO_WritePin(LED_Yellow_GPIO_Port,LED_Yellow_Pin,GPIO_PIN_SET);
           //逐组处理
            for(uint8_t i=0; i<9; i++)
            {
                // 读取第i组坐标
                int16_t current_tx = all_tx[i];
                int16_t current_ty = all_ty[i];
                int16_t current_bx = all_bx[i];
                int16_t current_by = all_by[i];

                // 转换为mm
                int txmm_9 = vision_to_mm(current_tx, zerox);
                int tymm_9 = vision_to_mm(current_ty, zeroy);
                int tbx_9 = vision_to_mm(current_tx, current_bx);
                int tby_9 = vision_to_mm(current_ty, current_by);
                int bxmm_9 = vision_to_mm(current_bx, zerox);
                int bymm_9 = vision_to_mm(current_by, zeroy);

                // 执行和模式1相同的移动逻辑
                Stepper_move_Right(txmm_9);
                HAL_Delay(1100);
                Stepper_move_Back(tymm_9);
                HAL_Delay(1100);
                // 【舵机吸附】
                sg90(120);
                HAL_Delay(1000);
//			          Magnet_On();
                HAL_Delay(200);
			          sg90(0);
                HAL_Delay(1000);
                Stepper_move_Right(tbx_9);
                HAL_Delay(1100);
                Stepper_move_Back(tby_9);
                HAL_Delay(1100);
                // 【舵机放下】
                sg90(120);
                HAL_Delay(1000);
//			          Magnet_Off();
                HAL_Delay(200);
			          sg90(0);
                HAL_Delay(1000);
                Stepper_move_Left(bxmm_9);
                HAL_Delay(1100);
                Stepper_move_Forward(bymm_9);
                HAL_Delay(1100);
            }

            // 重置标志，结束9组处理
            t_9groups_ready = 0;
            b_9groups_ready = 0;
            move = 0;
//						HAL_GPIO_WritePin(LED_Yellow_GPIO_Port,LED_Yellow_Pin,GPIO_PIN_RESET);
        }
  }
}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim == &htim3)
	{
		Stepper_TIM_IRQ_Handler(&x_motor);
	}
	
	if(htim == &htim1)
	{
		Stepper_TIM_IRQ_Handler(&y_motor);
	}
	
//	if(htim == &htim4)
//	{
//		Uart_ProcessData();
//	}
	
}

  



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
