/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Buzzer_Pin GPIO_PIN_5
#define Buzzer_GPIO_Port GPIOE
#define OLED_SDA_Pin GPIO_PIN_0
#define OLED_SDA_GPIO_Port GPIOC
#define LED_RED_Pin GPIO_PIN_1
#define LED_RED_GPIO_Port GPIOC
#define X_TIM_Pin GPIO_PIN_6
#define X_TIM_GPIO_Port GPIOA
#define X_EN_Pin GPIO_PIN_7
#define X_EN_GPIO_Port GPIOA
#define X_DIR_Pin GPIO_PIN_4
#define X_DIR_GPIO_Port GPIOC
#define Z_TIM_Pin GPIO_PIN_0
#define Z_TIM_GPIO_Port GPIOB
#define Z_DIR_Pin GPIO_PIN_2
#define Z_DIR_GPIO_Port GPIOB
#define Z_EN_Pin GPIO_PIN_7
#define Z_EN_GPIO_Port GPIOE
#define Y_EN_Pin GPIO_PIN_8
#define Y_EN_GPIO_Port GPIOE
#define Y_TIM_Pin GPIO_PIN_9
#define Y_TIM_GPIO_Port GPIOE
#define Y_DIR_Pin GPIO_PIN_10
#define Y_DIR_GPIO_Port GPIOE
#define OLED_SCL_Pin GPIO_PIN_12
#define OLED_SCL_GPIO_Port GPIOE
#define Laser_Pin GPIO_PIN_10
#define Laser_GPIO_Port GPIOB
#define KEY1_Pin GPIO_PIN_12
#define KEY1_GPIO_Port GPIOB
#define KEY1_EXTI_IRQn EXTI15_10_IRQn
#define KEY2_Pin GPIO_PIN_13
#define KEY2_GPIO_Port GPIOB
#define KEY2_EXTI_IRQn EXTI15_10_IRQn
#define KEY3_Pin GPIO_PIN_14
#define KEY3_GPIO_Port GPIOB
#define KEY3_EXTI_IRQn EXTI15_10_IRQn
#define KEY4_Pin GPIO_PIN_15
#define KEY4_GPIO_Port GPIOB
#define KEY4_EXTI_IRQn EXTI15_10_IRQn
#define KEY5_Pin GPIO_PIN_9
#define KEY5_GPIO_Port GPIOD
#define KEY5_EXTI_IRQn EXTI9_5_IRQn
#define LED_GREEN_Pin GPIO_PIN_11
#define LED_GREEN_GPIO_Port GPIOD
#define LED_BLUE_Pin GPIO_PIN_13
#define LED_BLUE_GPIO_Port GPIOD
#define Tmc2209_TX_Pin GPIO_PIN_9
#define Tmc2209_TX_GPIO_Port GPIOA
#define Tmc2209_RX_Pin GPIO_PIN_10
#define Tmc2209_RX_GPIO_Port GPIOA
#define OLED_SCLB8_Pin GPIO_PIN_8
#define OLED_SCLB8_GPIO_Port GPIOB
#define OLED_SDAB9_Pin GPIO_PIN_9
#define OLED_SDAB9_GPIO_Port GPIOB
#define LED_YELLOW_Pin GPIO_PIN_1
#define LED_YELLOW_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
